module cmp32 (
    input wire clk,
    input wire rst_n,
    input wire valid_i,
    input wire [31:0] a_i,
    input wire [31:0] b_i,
    output reg valid_o,
    output reg [0:0] y_o
);

wire lt_0 = (a_i[0] < b_i[0]);
wire eq_0 = (a_i[0] == b_i[0]);
wire lt_1 = (a_i[1] < b_i[1]);
wire eq_1 = (a_i[1] == b_i[1]);
wire lt_2 = (a_i[2] < b_i[2]);
wire eq_2 = (a_i[2] == b_i[2]);
wire lt_3 = (a_i[4:3] < b_i[4:3]);
wire eq_3 = (a_i[4:3] == b_i[4:3]);
wire lt_4 = (a_i[5] < b_i[5]);
wire eq_4 = (a_i[5] == b_i[5]);
wire lt_5 = (a_i[6] < b_i[6]);
wire eq_5 = (a_i[6] == b_i[6]);
wire lt_6 = (a_i[7] < b_i[7]);
wire eq_6 = (a_i[7] == b_i[7]);
wire lt_7 = (a_i[8] < b_i[8]);
wire eq_7 = (a_i[8] == b_i[8]);
wire lt_8 = (a_i[10:9] < b_i[10:9]);
wire eq_8 = (a_i[10:9] == b_i[10:9]);
wire lt_9 = (a_i[11] < b_i[11]);
wire eq_9 = (a_i[11] == b_i[11]);
wire lt_10 = (a_i[13:12] < b_i[13:12]);
wire eq_10 = (a_i[13:12] == b_i[13:12]);
wire lt_11 = (a_i[14] < b_i[14]);
wire eq_11 = (a_i[14] == b_i[14]);
wire lt_12 = (a_i[15] < b_i[15]);
wire eq_12 = (a_i[15] == b_i[15]);
wire lt_13 = (a_i[16] < b_i[16]);
wire eq_13 = (a_i[16] == b_i[16]);
wire lt_14 = (a_i[17] < b_i[17]);
wire eq_14 = (a_i[17] == b_i[17]);
wire lt_15 = (a_i[18] < b_i[18]);
wire eq_15 = (a_i[18] == b_i[18]);
wire lt_16 = (a_i[20:19] < b_i[20:19]);
wire eq_16 = (a_i[20:19] == b_i[20:19]);
wire lt_17 = (a_i[23:21] < b_i[23:21]);
wire eq_17 = (a_i[23:21] == b_i[23:21]);
wire lt_18 = (a_i[24] < b_i[24]);
wire eq_18 = (a_i[24] == b_i[24]);
wire lt_19 = (a_i[26:25] < b_i[26:25]);
wire eq_19 = (a_i[26:25] == b_i[26:25]);
wire lt_20 = (a_i[27] < b_i[27]);
wire eq_20 = (a_i[27] == b_i[27]);
wire lt_21 = (a_i[28] < b_i[28]);
wire eq_21 = (a_i[28] == b_i[28]);
wire lt_22 = (a_i[29] < b_i[29]);
wire eq_22 = (a_i[29] == b_i[29]);
wire lt_23 = (a_i[30] < b_i[30]);
wire eq_23 = (a_i[30] == b_i[30]);
wire lt_24 = (a_i[31] < b_i[31]);
wire eq_24 = (a_i[31] == b_i[31]);

wire cmp_0 = lt_0;
wire cmp_1 = lt_1 | (eq_1 & cmp_0);
wire cmp_2 = lt_2 | (eq_2 & cmp_1);
wire cmp_3 = lt_3 | (eq_3 & cmp_2);
wire cmp_4 = lt_4 | (eq_4 & cmp_3);
wire cmp_5 = lt_5 | (eq_5 & cmp_4);
wire cmp_6 = lt_6 | (eq_6 & cmp_5);
wire cmp_7 = lt_7 | (eq_7 & cmp_6);
wire cmp_8 = lt_8 | (eq_8 & cmp_7);
wire cmp_9 = lt_9 | (eq_9 & cmp_8);
wire cmp_10 = lt_10 | (eq_10 & cmp_9);
wire cmp_11 = lt_11 | (eq_11 & cmp_10);
wire cmp_12 = lt_12 | (eq_12 & cmp_11);
wire cmp_13 = lt_13 | (eq_13 & cmp_12);
wire cmp_14 = lt_14 | (eq_14 & cmp_13);
wire cmp_15 = lt_15 | (eq_15 & cmp_14);
wire cmp_16 = lt_16 | (eq_16 & cmp_15);
wire cmp_17 = lt_17 | (eq_17 & cmp_16);
wire cmp_18 = lt_18 | (eq_18 & cmp_17);
wire cmp_19 = lt_19 | (eq_19 & cmp_18);
wire cmp_20 = lt_20 | (eq_20 & cmp_19);
wire cmp_21 = lt_21 | (eq_21 & cmp_20);
wire cmp_22 = lt_22 | (eq_22 & cmp_21);
wire cmp_23 = lt_23 | (eq_23 & cmp_22);
wire cmp_24 = lt_24 | (eq_24 & cmp_23);

always @(posedge clk) begin
    if (!rst_n) begin
        valid_o <= 1'b0;
        y_o <= 1'd0;
    end else begin
        valid_o <= valid_i;
        if (valid_i)
            y_o <= cmp_24;
    end
end
endmodule
